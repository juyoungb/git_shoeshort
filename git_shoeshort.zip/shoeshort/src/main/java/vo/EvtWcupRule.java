package vo;

public class EvtWcupRule {
	String ewj_idx, ew_idx, mi_id,	ewj_vid, ewj_ing, ewj_seq, ewj_status;

	public String getEwj_idx() {
		return ewj_idx;
	}

	public void setEwj_idx(String ewj_idx) {
		this.ewj_idx = ewj_idx;
	}

	public String getEw_idx() {
		return ew_idx;
	}

	public void setEw_idx(String ew_idx) {
		this.ew_idx = ew_idx;
	}

	public String getMi_id() {
		return mi_id;
	}

	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}

	public String getEwj_vid() {
		return ewj_vid;
	}

	public void setEwj_vid(String ewj_vid) {
		this.ewj_vid = ewj_vid;
	}

	public String getEwj_ing() {
		return ewj_ing;
	}

	public void setEwj_ing(String ewj_ing) {
		this.ewj_ing = ewj_ing;
	}

	public String getEwj_seq() {
		return ewj_seq;
	}

	public void setEwj_seq(String ewj_seq) {
		this.ewj_seq = ewj_seq;
	}

	public String getEwj_status() {
		return ewj_status;
	}

	public void setEwj_status(String ewj_status) {
		this.ewj_status = ewj_status;
	}
	
}
