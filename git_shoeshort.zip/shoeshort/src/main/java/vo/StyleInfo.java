package vo;

public class StyleInfo {
	private String mi_id, pi_id, si_img, si_content, si_isview, si_date;
	private int si_idx, si_good, si_read, si_result;
	
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getPi_id() {
		return pi_id;
	}
	public void setPi_id(String pi_id) {
		this.pi_id = pi_id;
	}
	public String getSi_img() {
		return si_img;
	}
	public void setSi_img(String si_img) {
		this.si_img = si_img;
	}
	public String getSi_content() {
		return si_content;
	}
	public void setSi_content(String si_text) {
		this.si_content = si_text;
	}
	public String getSi_isview() {
		return si_isview;
	}
	public void setSi_isview(String si_isview) {
		this.si_isview = si_isview;
	}
	public String getSi_date() {
		return si_date;
	}
	public void setSi_date(String si_date) {
		this.si_date = si_date;
	}
	public int getSi_idx() {
		return si_idx;
	}
	public void setSi_idx(int si_idx) {
		this.si_idx = si_idx;
	}
	public int getSi_good() {
		return si_good;
	}
	public void setSi_good(int si_good) {
		this.si_good = si_good;
	}
	public int getSi_read() {
		return si_read;
	}
	public void setSi_read(int si_read) {
		this.si_read = si_read;
	}
	public int getSi_result() {
		return si_result;
	}
	public void setSi_result(int si_result) {
		this.si_result = si_result;
	}
	
}
