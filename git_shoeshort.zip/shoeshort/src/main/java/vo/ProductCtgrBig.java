package vo;

public class ProductCtgrBig {  
	private String pcb_id, pcb_name;

	public String getPcb_id() {
		return pcb_id;
	}

	public void setPcb_id(String pcb_id) {
		this.pcb_id = pcb_id;
	}

	public String getPcb_name() {
		return pcb_name;
	}

	public void setPcb_name(String pcb_name) {
		this.pcb_name = pcb_name;
	}
}
