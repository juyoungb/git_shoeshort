package vo;

public class StoreInfo {
	private int bsi_idx, ai_idx;
	private String pb_id, bsi_name, bsi_addr, bsi_isview, bsi_brand, bsi_date;
	public int getBsi_idx() {
		return bsi_idx;
	}
	public void setBsi_idx(int bsi_idx) {
		this.bsi_idx = bsi_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public String getPb_id() {
		return pb_id;
	}
	public void setPb_id(String pb_id) {
		this.pb_id = pb_id;
	}
	public String getBsi_name() {
		return bsi_name;
	}
	public void setBsi_name(String bsi_name) {
		this.bsi_name = bsi_name;
	}
	public String getBsi_addr() {
		return bsi_addr;
	}
	public void setBsi_addr(String bsi_addr) {
		this.bsi_addr = bsi_addr;
	}
	public String getBsi_date() {
		return bsi_date;
	}
	public void setBsi_date(String bsi_date) {
		this.bsi_date = bsi_date;
	}
	public String getBsi_isview() {
		return bsi_isview;
	}
	public void setBsi_isview(String bsi_isview) {
		this.bsi_isview = bsi_isview;
	}
	public String getBsi_brand() {
		return bsi_brand;
	}
	public void setBsi_brand(String bsi_brand) {
		this.bsi_brand = bsi_brand;
	}
	
}
