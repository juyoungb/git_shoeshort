package vo;

public class FaqList {
	private int fl_idx, ai_idx, fl_read;
	private String fl_title, fl_content, fl_answer	, fl_isview, fl_date;
	public int getFl_idx() {
		return fl_idx;
	}
	public void setFl_idx(int fl_idx) {
		this.fl_idx = fl_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public int getFl_read() {
		return fl_read;
	}
	public void setFl_read(int fl_read) {
		this.fl_read = fl_read;
	}
	public String getFl_title() {
		return fl_title;
	}
	public void setFl_title(String fl_title) {
		this.fl_title = fl_title;
	}
	public String getFl_content() {
		return fl_content;
	}
	public void setFl_content(String fl_content) {
		this.fl_content = fl_content;
	}
	public String getFl_answer() {
		return fl_answer;
	}
	public void setFl_answer(String fl_answer) {
		this.fl_answer = fl_answer;
	}
	public String getFl_isview() {
		return fl_isview;
	}
	public void setFl_isview(String fl_isview) {
		this.fl_isview = fl_isview;
	}
	public String getFl_date() {
		return fl_date;
	}
	public void setFl_date(String fl_date) {
		this.fl_date = fl_date;
	}
	
}
