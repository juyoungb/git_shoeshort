package vo;

public class MainMedia {
	private int mm_idx, ai_idx,mm_seq; 
	private String mm_name, mm_media,  mm_date, mm_isview, mm_link;
	public int getMm_idx() {
		return mm_idx;
	}
	public void setMm_idx(int mm_idx) {
		this.mm_idx = mm_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public int getMm_seq() {
		return mm_seq;
	}
	public void setMm_seq(int mm_seq) {
		this.mm_seq = mm_seq;
	}
	public String getMm_name() {
		return mm_name;
	}
	public void setMm_name(String mm_name) {
		this.mm_name = mm_name;
	}
	public String getMm_media() {
		return mm_media;
	}
	public void setMm_media(String mm_media) {
		this.mm_media = mm_media;
	}
	public String getMm_date() {
		return mm_date;
	}
	public void setMm_date(String mm_date) {
		this.mm_date = mm_date;
	}
	public String getMm_isview() {
		return mm_isview;
	}
	public void setMm_isview(String mm_isview) {
		this.mm_isview = mm_isview;
	}
	public String getMm_link() {
		return mm_link;
	}
	public void setMm_link(String mm_link) {
		this.mm_link = mm_link;
	}
	
	
}
