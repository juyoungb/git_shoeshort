package vo;

public class WcupDetail {
	private int ewl_win, total, late;
	private String mi_id, si_img, pi_id, si_idx;
	public int getEwl_win() {
		return ewl_win;
	}
	public void setEwl_win(int ewl_win) {
		this.ewl_win = ewl_win;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getLate() {
		return late;
	}
	public void setLate(int late) {
		this.late = late;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getSi_img() {
		return si_img;
	}
	public void setSi_img(String si_img) {
		this.si_img = si_img;
	}
	public String getPi_id() {
		return pi_id;
	}
	public void setPi_id(String pi_id) {
		this.pi_id = pi_id;
	}
	public String getSi_idx() {
		return si_idx;
	}
	public void setSi_idx(String si_idx) {
		this.si_idx = si_idx;
	}
	
	
}
