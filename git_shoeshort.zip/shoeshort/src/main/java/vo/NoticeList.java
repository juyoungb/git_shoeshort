package vo;

public class NoticeList {
	private int  nl_idx, ai_idx, nl_read;
	private String nl_ctgr, nl_title, nl_content, nl_isview, nl_date;
	public int getNl_idx() {
		return nl_idx;
	}
	public void setNl_idx(int nl_idx) {
		this.nl_idx = nl_idx;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public int getNl_read() {
		return nl_read;
	}
	public void setNl_read(int nl_read) {
		this.nl_read = nl_read;
	}
	public String getNl_ctgr() {
		return nl_ctgr;
	}
	public void setNl_ctgr(String nl_ctgr) {
		this.nl_ctgr = nl_ctgr;
	}
	public String getNl_title() {
		return nl_title;
	}
	public void setNl_title(String nl_title) {
		this.nl_title = nl_title;
	}
	public String getNl_content() {
		return nl_content;
	}
	public void setNl_content(String nl_content) {
		this.nl_content = nl_content;
	}
	public String getNl_isview() {
		return nl_isview;
	}
	public void setNl_isview(String nl_isview) {
		this.nl_isview = nl_isview;
	}
	public String getNl_date() {
		return nl_date;
	}
	public void setNl_date(String nl_date) {
		this.nl_date = nl_date;
	}
	
}
