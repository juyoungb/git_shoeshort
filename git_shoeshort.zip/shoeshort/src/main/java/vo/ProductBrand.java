package vo;

public class ProductBrand {
// 하나의 상품 브랜드 정보를 저장할 클래스
	private String pb_id, pb_name;
	
	public String getPb_id() {
		return pb_id;
	}
	
	public void setPb_id(String pb_id) {
		this.pb_id = pb_id;
	}
	
	public String getPb_name() {
		return pb_name;
	}
	
	public void setPb_name(String pb_name) {
		this.pb_name = pb_name;
	}

}

