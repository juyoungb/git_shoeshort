package vo;



public class PageInfo {
// �Խ��Ǹ��, ��ǰ��� ��� ����¡�� �ʿ��� �������� ������ Ŭ����
	private int cpage,  spage, psize, bsize, rcnt , pcnt, num, count;
	private String schtype, keyword, args, schargs, pcb, pcs, obargs, vargs, sch, ob, v, schG, schA,schS, schK;	
	private String init;
	// schG = �˻����� ����, schS = �˻����� ����, schA = �˻����� ���ɺ�, schK = �˻����� Ű����
	
	public int getCpage() {
		return cpage;
	}
	public void setCpage(int cpage) {
		this.cpage = cpage;
	}
	public int getSpage() {
		return spage;
	}
	public void setSpage(int spage) {
		this.spage = spage;
	}
	
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getPsize() {
		return psize;
	}
	public void setPsize(int psize) {
		this.psize = psize;
	}
	public int getBsize() {
		return bsize;
	}
	public void setBsize(int bsize) {
		this.bsize = bsize;
	}
	public int getRcnt() {
		return rcnt;
	}
	public void setRcnt(int rcnt) {
		this.rcnt = rcnt;
	}
	public int getPcnt() {
		return pcnt;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public void setPcnt(int pcnt) {
		this.pcnt = pcnt;
	}
	public String getSchtype() {
		return schtype;
	}
	public void setSchtype(String schtype) {
		this.schtype = schtype;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getArgs() {
		return args;
	}
	public void setArgs(String args) {
		this.args = args;
	}
	public String getSchargs() {
		return schargs;
	}
	public void setSchargs(String schargs) {
		this.schargs = schargs;
	}
	public String getPcb() {
		return pcb;
	}
	public void setPcb(String pcb) {
		this.pcb = pcb;
	}
	public String getPcs() {
		return pcs;
	}
	public void setPcs(String pcs) {
		this.pcs = pcs;
	}
	public String getObargs() {
		return obargs;
	}
	public void setObargs(String obargs) {
		this.obargs = obargs;
	}
	public String getVargs() {
		return vargs;
	}
	public void setVargs(String vargs) {
		this.vargs = vargs;
	}
	public String getSch() {
		return sch;
	}
	public void setSch(String sch) {
		this.sch = sch;
	}
	public String getOb() {
		return ob;
	}
	public void setOb(String ob) {
		this.ob = ob;
	}
	public String getV() {
		return v;
	}
	public void setV(String v) {
		this.v = v;
	}
	public String getSchG() {
		return schG;
	}
	public void setSchG(String schG) {
		this.schG = schG;
	}
	public String getSchA() {
		return schA;
	}
	public void setSchA(String schA) {
		this.schA = schA;
	}
	public String getSchS() {
		return schS;
	}
	public void setSchS(String schS) {
		this.schS = schS;
	}
	public String getSchK() {
		return schK;
	}
	public void setSchK(String schK) {
		this.schK = schK;
	}
	public String getInit() {
		return init;
	}
	public void setInit(String init) {
		this.init = init;
	}


	
}
