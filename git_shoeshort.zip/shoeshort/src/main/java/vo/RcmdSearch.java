package vo;

public class RcmdSearch {
	private String pi_gubun = "m,w,k";
	private String pi_rc_season = "봄,여름,가을,겨울"; 
	private String pi_rc_age = "10대,20대,30대,40대";
	private String pi_rc_keyword = "바닷가, 졸업식, 수학여행, 결혼식, 소개팅";
	
	public String getPi_gubun() {
		return pi_gubun;
	}
	public void setPi_gubun(String pi_gubun) {
		this.pi_gubun = pi_gubun;
	}
	public String getPi_rc_season() {
		return pi_rc_season;
	}
	public void setPi_rc_season(String pi_rc_season) {
		this.pi_rc_season = pi_rc_season;
	}
	public String getPi_rc_age() {
		return pi_rc_age;
	}
	public void setPi_rc_age(String pi_rc_age) {
		this.pi_rc_age = pi_rc_age;
	}
	public String getPi_rc_keyword() {
		return pi_rc_keyword;
	}
	public void setPi_rc_keyword(String pi_rc_keyword) {
		this.pi_rc_keyword = pi_rc_keyword;
	}
	
}
