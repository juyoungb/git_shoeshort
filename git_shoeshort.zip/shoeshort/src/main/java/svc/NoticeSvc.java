package svc;

import java.util.*;
import dao.*;
import vo.*;

public class NoticeSvc {
	private NoticeDao noticeDao;
	
	public void setNoticeDao(NoticeDao noticeDao) {
		this.noticeDao = noticeDao;
	}
}
