package svc;

import java.util.*;
import dao.*;
import vo.*;

public class AdMainSvc {
	private AdMainDao adMainDao;

	public void setAdMainDao(AdMainDao adMainDao) {
		this.adMainDao = adMainDao;
	}
	
}
