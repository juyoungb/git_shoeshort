package vo;

public class NoticeInfo {
	private String nl_idx, nl_ctgr, nl_title;
	
	
	public String getNl_idx() {
		return nl_idx;
	}

	public void setNl_idx(String nl_idx) {
		this.nl_idx = nl_idx;
	}

	public String getNl_ctgr() {
		return nl_ctgr;
	}

	public void setNl_ctgr(String nl_ctgr) {
		this.nl_ctgr = nl_ctgr;
	}

	public String getNl_title() {
		return nl_title;
	}

	public void setNl_title(String nl_title) {
		this.nl_title = nl_title;
	}
	
}
