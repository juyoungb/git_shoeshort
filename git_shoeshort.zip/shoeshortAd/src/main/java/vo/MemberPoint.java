package vo;

public class MemberPoint {
	int mp_idx,	mp_point, ai_idx;
	String mi_id, mi_name, mp_su, mp_desc, mp_detail, mp_sdate, mp_edate;
	public int getMp_idx() {
		return mp_idx;
	}
	public void setMp_idx(int mp_idx) {
		this.mp_idx = mp_idx;
	}
	public int getMp_point() {
		return mp_point;
	}
	public void setMp_point(int mp_point) {
		this.mp_point = mp_point;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getMp_su() {
		return mp_su;
	}
	public void setMp_su(String mp_su) {
		this.mp_su = mp_su;
	}
	public String getMp_desc() {
		return mp_desc;
	}
	public void setMp_desc(String mp_desc) {
		this.mp_desc = mp_desc;
	}
	public String getMp_detail() {
		return mp_detail;
	}
	public void setMp_detail(String mp_detail) {
		this.mp_detail = mp_detail;
	}
	public String getMi_name() {
		return mi_name;
	}
	public void setMi_name(String mi_name) {
		this.mi_name = mi_name;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public String getMp_sdate() {
		return mp_sdate;
	}
	public void setMp_sdate(String mp_sdate) {
		this.mp_sdate = mp_sdate;
	}
	public String getMp_edate() {
		return mp_edate;
	}
	public void setMp_edate(String mp_edate) {
		this.mp_edate = mp_edate;
	}
	
}
