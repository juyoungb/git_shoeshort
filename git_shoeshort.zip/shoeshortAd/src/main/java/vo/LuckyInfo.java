package vo;

public class LuckyInfo {
	private int el_idx, td_idx, td_price,ai_idx, el_min_price, el_max_price,el_final_price;
	private String el_title, pi_id,	mi_id, pi_img1, el_sdate,sdate, el_edate,edate, el_date, el_isview, pi_name, stime, etime;
	
	public int getEl_idx() {
		return el_idx;
	}
	public void setEl_idx(int el_idx) {
		this.el_idx = el_idx;
	}
	public int getTd_idx() {
		return td_idx;
	}
	public void setTd_idx(int td_idx) {
		this.td_idx = td_idx;
	}
	public int getTd_price() {
		return td_price;
	}
	public void setTd_price(int td_price) {
		this.td_price = td_price;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public int getEl_min_price() {
		return el_min_price;
	}
	public void setEl_min_price(int el_min_price) {
		this.el_min_price = el_min_price;
	}
	public int getEl_max_price() {
		return el_max_price;
	}
	public void setEl_max_price(int el_max_price) {
		this.el_max_price = el_max_price;
	}
	public int getEl_final_price() {
		return el_final_price;
	}
	public void setEl_final_price(int el_final_price) {
		this.el_final_price = el_final_price;
	}
	public String getEl_title() {
		return el_title;
	}
	public void setEl_title(String el_title) {
		this.el_title = el_title;
	}
	public String getPi_id() {
		return pi_id;
	}
	public void setPi_id(String pi_id) {
		this.pi_id = pi_id;
	}
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getPi_img1() {
		return pi_img1;
	}
	public void setPi_img1(String pi_img1) {
		this.pi_img1 = pi_img1;
	}
	public String getEl_sdate() {
		return el_sdate;
	}
	public void setEl_sdate(String el_sdate) {
		this.el_sdate = el_sdate;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	public String getEl_edate() {
		return el_edate;
	}
	public void setEl_edate(String el_edate) {
		this.el_edate = el_edate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}
	public String getEl_date() {
		return el_date;
	}
	public void setEl_date(String el_date) {
		this.el_date = el_date;
	}
	public String getEl_isview() {
		return el_isview;
	}
	public void setEl_isview(String el_isview) {
		this.el_isview = el_isview;
	}
	public String getPi_name() {
		return pi_name;
	}
	public void setPi_name(String pi_name) {
		this.pi_name = pi_name;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getEtime() {
		return etime;
	}
	public void setEtime(String etime) {
		this.etime = etime;
	}
	
	
}